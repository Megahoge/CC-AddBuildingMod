ダウンロードありがとうございます。
Steamでガイドを作成していますので、そちらを御覧ください。

Thank you for downloading.
We have created a guide on Steam for you to follow.

Guide: https://steamcommunity.com/sharedfiles/filedetails/?id=2603175759&preview=true

---- 更新履歴 ----
2021/09/18 v0.9999
    CCSEと競合する問題を修正

2021/09/16 v0.999
    新規
